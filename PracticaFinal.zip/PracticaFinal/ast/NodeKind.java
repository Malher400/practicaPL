package ast;

public enum NodeKind {
  EXPRESSION, INSTRUCTION, TYPE, DECLARATION, PROGRAM
}
