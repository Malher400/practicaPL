package ast;

public enum KindIns {
    ASIG, BLOCK, IF, IF_ELSE, WHILE, FOR, WRITE, DELETE, CALL
}