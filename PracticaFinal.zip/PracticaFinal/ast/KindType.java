package ast;

public enum KindType {
    ENT, BOOL, ARRAY, POINTER, IDEN, REF, FUN, STRUCT, NULL
}