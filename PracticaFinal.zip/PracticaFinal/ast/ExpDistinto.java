package ast;

import errors.TypeException;

public class ExpDistinto extends EBin {

   public ExpDistinto(int fila, int columna, Exp opnd1, Exp opnd2) {
      super(fila, columna, KindExp.DISTINTO, opnd1, opnd2);
   }

   public String toString() {
      return "  |ExpDistinto| (" + opnd1.toString() + " != " + opnd2.toString() + ')';
   }

   public void type() throws TypeException {
      super.type();
      if (opnd1.getTipo().getKindType() == opnd2.getTipo().getKindType() && opnd1.getTipo().isAssignable()
            && opnd2.getTipo().isAssignable()) {
         tipo = new TypeBool();
         tipo.type();
      } else
         throw new TypeException(opnd1.getFila(), opnd2.getColumna(), "Los operandos tienen diferente tipo");
   }

   public String generateCode(int depth) {
      StringBuilder ss = new StringBuilder();
      ss.append(super.generateCode(depth));
      ss.append("\ti32.ne\n");
      return ss.toString();
   }

}
