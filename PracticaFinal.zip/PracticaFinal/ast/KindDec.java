package ast;

public enum KindDec {
    TIPO, STRUCT, VARIABLE, CONSTANTE, FUNCION, FUNVOID
}